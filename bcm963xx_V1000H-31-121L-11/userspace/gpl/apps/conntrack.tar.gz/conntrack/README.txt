conntrack-tools need libnfnetlink & libnetfilter_conntrack libraries.
These libraries were cross compiled and copied to conntrack/libs & conntrack/includes.

